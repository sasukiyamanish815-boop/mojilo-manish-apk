package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.QuestionItem
import com.example.data.models.TestItem
import com.example.data.models.UserProfile
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    user: UserProfile?,
    students: List<UserProfile>,
    tests: List<TestItem>,
    selectedTestForQuestions: TestItem?,
    questionsForTest: List<QuestionItem>,
    isLoading: Boolean,
    onAddStudent: (name: String, mobile: String, pass: String) -> Unit,
    onUpdateStudent: (id: String, name: String, mobile: String, pass: String, isActive: Boolean) -> Unit,
    onDeleteStudent: (id: String) -> Unit,
    onResetDeviceLock: (id: String) -> Unit,
    onCreateTest: (title: String, isActive: Boolean, reattemptAllowed: Boolean) -> Unit,
    onUpdateTest: (id: String, title: String, isActive: Boolean, reattemptAllowed: Boolean) -> Unit,
    onDeleteTest: (id: String) -> Unit,
    onSelectTestForQuestions: (TestItem) -> Unit,
    onAddQuestion: (testId: String, qText: String, options: List<String>, correctIndex: Int, marks: Int) -> Unit,
    onUpdateQuestion: (id: String, testId: String, qText: String, options: List<String>, correctIndex: Int, marks: Int) -> Unit,
    onDeleteQuestion: (id: String, testId: String) -> Unit,
    onLogout: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Students, 1: Tests, 2: Questions, 3: DB Setup
    var showAddStudentDialog by remember { mutableStateOf(false) }
    var showCreateTestDialog by remember { mutableStateOf(false) }
    var editingStudent by remember { mutableStateOf<UserProfile?>(null) }
    var editingTest by remember { mutableStateOf<TestItem?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Mojilo Manish Admin Panel",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = "સંપૂર્ણ એડમિન કંટ્રોલ સેન્ટર",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.8f))
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onLogout,
                        modifier = Modifier.testTag("admin_logout_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Logout", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PurpleHeaderDark,
                    titleContentColor = Color.White
                ),
                windowInsets = WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Top)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Admin Navigation Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                edgePadding = 12.dp
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("વિદ્યાર્થીઓ (${students.size})") },
                    icon = { Icon(Icons.Default.Group, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("પરીક્ષાઓ (${tests.size})") },
                    icon = { Icon(Icons.Default.Quiz, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("પ્રશ્નો") },
                    icon = { Icon(Icons.Default.FormatListBulleted, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Supabase DB Setup") },
                    icon = { Icon(Icons.Default.Storage, contentDescription = null) }
                )
            }

            if (isLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = IndigoPrimary)
            }

            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    0 -> AdminStudentsTab(
                        students = students,
                        onAddClick = { showAddStudentDialog = true },
                        onEditClick = { editingStudent = it },
                        onDeleteClick = { onDeleteStudent(it.id) },
                        onResetDeviceLock = onDeleteStudentLock@{ student -> onResetDeviceLock(student.id) }
                    )
                    1 -> AdminTestsTab(
                        tests = tests,
                        onCreateClick = { showCreateTestDialog = true },
                        onEditClick = { editingTest = it },
                        onDeleteClick = { onDeleteTest(it.id) },
                        onManageQuestionsClick = { test ->
                            onSelectTestForQuestions(test)
                            selectedTab = 2
                        }
                    )
                    2 -> AdminQuestionsTab(
                        tests = tests,
                        selectedTest = selectedTestForQuestions,
                        questions = questionsForTest,
                        onSelectTest = onSelectTestForQuestions,
                        onAddQuestion = onAddQuestion,
                        onUpdateQuestion = onUpdateQuestion,
                        onDeleteQuestion = onDeleteQuestion
                    )
                    3 -> AdminDatabaseSetupTab()
                }
            }
        }
    }

    if (showAddStudentDialog) {
        StudentDialog(
            student = null,
            onDismiss = { showAddStudentDialog = false },
            onSave = { name, mobile, pass, _ ->
                onAddStudent(name, mobile, pass)
                showAddStudentDialog = false
            }
        )
    }

    if (editingStudent != null) {
        StudentDialog(
            student = editingStudent,
            onDismiss = { editingStudent = null },
            onSave = { name, mobile, pass, isActive ->
                onUpdateStudent(editingStudent!!.id, name, mobile, pass, isActive)
                editingStudent = null
            }
        )
    }

    if (showCreateTestDialog) {
        TestDialog(
            test = null,
            onDismiss = { showCreateTestDialog = false },
            onSave = { title, isActive, reattemptAllowed ->
                onCreateTest(title, isActive, reattemptAllowed)
                showCreateTestDialog = false
            }
        )
    }

    if (editingTest != null) {
        TestDialog(
            test = editingTest,
            onDismiss = { editingTest = null },
            onSave = { title, isActive, reattempt ->
                onUpdateTest(editingTest!!.id, title, isActive, reattempt)
                editingTest = null
            }
        )
    }
}

// TAB 1: STUDENTS MANAGEMENT
@Composable
fun AdminStudentsTab(
    students: List<UserProfile>,
    onAddClick: () -> Unit,
    onEditClick: (UserProfile) -> Unit,
    onDeleteClick: (UserProfile) -> Unit,
    onResetDeviceLock: (UserProfile) -> Unit
) {
    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddClick,
                icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
                text = { Text("નવો વિદ્યાર્થી ઉમેરો") },
                containerColor = IndigoPrimary,
                contentColor = Color.White
            )
        }
    ) { padding ->
        if (students.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("કોઈ વિદ્યાર્થીઓ મળ્યા નથી.")
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                items(students, key = { it.id }) { student ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = SlateSurface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = student.name,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "મોબાઈલ: ${student.mobileNumber} | પાવર્ડ: ${student.password}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (student.isActive) EmeraldContainer else RoseContainer
                                ) {
                                    Text(
                                        text = if (student.isActive) "Active" else "Inactive",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (student.isActive) EmeraldOnContainer else RoseError
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Device Lock Status & Reset Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val isLocked = !student.activeDeviceId.isNull_or_empty()
                                Text(
                                    text = if (isLocked) "🔒 Device Locked" else "🔓 No Active Device",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Medium,
                                        color = if (isLocked) AmberWarning else TextMuted
                                    )
                                )

                                Row {
                                    if (isLocked) {
                                        TextButton(onClick = { onResetDeviceLock(student) }) {
                                            Text("Unlock Device", fontSize = 12.sp, color = AmberWarning)
                                        }
                                    }
                                    IconButton(onClick = { onEditClick(student) }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = IndigoPrimary)
                                    }
                                    IconButton(onClick = { onDeleteClick(student) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = RoseError)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// TAB 2: TESTS MANAGEMENT
@Composable
fun AdminTestsTab(
    tests: List<TestItem>,
    onCreateClick: () -> Unit,
    onEditClick: (TestItem) -> Unit,
    onDeleteClick: (TestItem) -> Unit,
    onManageQuestionsClick: (TestItem) -> Unit
) {
    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onCreateClick,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("નવી પરીક્ષા બનાવો") },
                containerColor = IndigoPrimary,
                contentColor = Color.White
            )
        }
    ) { padding ->
        if (tests.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("કોઈ પરીક્ષાઓ ઉપલબ્ધ નથી.")
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                items(tests, key = { it.id }) { test ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = SlateSurface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = test.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.weight(1f)
                                )

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (test.isActive) EmeraldContainer else RoseContainer
                                ) {
                                    Text(
                                        text = if (test.isActive) "Active" else "Inactive",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (test.isActive) EmeraldOnContainer else RoseError
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Keep the description and action buttons on separate rows so
                            // Gujarati text never overlaps the "પ્રશ્નો મેનેજ કરો" button.
                            Text(
                                text = "Reattempt Allowed: ${if (test.reattemptAllowed) "ON" else "OFF"}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { onManageQuestionsClick(test) },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        "પ્રશ્નો મેનેજ કરો",
                                        fontSize = 12.sp,
                                        maxLines = 1
                                    )
                                }

                                IconButton(onClick = { onEditClick(test) }) {
                                    Icon(
                                        Icons.Default.Edit,
                                        contentDescription = "Edit",
                                        tint = IndigoPrimary
                                    )
                                }

                                IconButton(onClick = { onDeleteClick(test) }) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = RoseError
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// TAB 3: QUESTIONS MANAGEMENT
@Composable
fun AdminQuestionsTab(
    tests: List<TestItem>,
    selectedTest: TestItem?,
    questions: List<QuestionItem>,
    onSelectTest: (TestItem) -> Unit,
    onAddQuestion: (testId: String, qText: String, options: List<String>, correctIndex: Int, marks: Int) -> Unit,
    onUpdateQuestion: (id: String, testId: String, qText: String, options: List<String>, correctIndex: Int, marks: Int) -> Unit,
    onDeleteQuestion: (id: String, testId: String) -> Unit
) {
    var showAddQuestionDialog by remember { mutableStateOf(false) }
    var editingQuestion by remember { mutableStateOf<QuestionItem?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Test Selector Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = SlateSurface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "પરીક્ષા પસંદ કરો:",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (tests.isEmpty()) {
                    Text("પહેલાં પરીક્ષા બનાવો.")
                } else {
                    ScrollableTabRow(
                        selectedTabIndex = tests.indexOfFirst { it.id == selectedTest?.id }.coerceAtLeast(0),
                        edgePadding = 0.dp
                    ) {
                        tests.forEach { test ->
                            Tab(
                                selected = test.id == selectedTest?.id,
                                onClick = { onSelectTest(test) },
                                text = { Text(test.title, maxLines = 1) }
                            )
                        }
                    }
                }
            }
        }

        if (selectedTest == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("પ્રશ્નો જોવા માટે ઉપરથી પરીક્ષા પસંદ કરો.")
            }
        } else {
            Scaffold(
                floatingActionButton = {
                    ExtendedFloatingActionButton(
                        onClick = { showAddQuestionDialog = true },
                        icon = { Icon(Icons.Default.Add, contentDescription = null) },
                        text = { Text("નવો પ્રશ્ન ઉમેરો") },
                        containerColor = IndigoPrimary,
                        contentColor = Color.White
                    )
                }
            ) { padding ->
                if (questions.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("આ પરીક્ષામાં કોઈ પ્રશ્નો ઉમેરાયેલ નથી.")
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                    ) {
                        items(questions, key = { it.id }) { q ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = SlateSurface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = q.questionText,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text(
                                            text = "${q.marks} Marks",
                                            style = MaterialTheme.typography.labelLarge.copy(
                                                color = IndigoPrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    q.options.forEachIndexed { index, option ->
                                        val isCorrect = index == q.correctOptionIndex
                                        Text(
                                            text = "${if (isCorrect) "✓ " else "   "} (${index + 1}) $option",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                color = if (isCorrect) EmeraldSuccess else TextSecondary,
                                                fontWeight = if (isCorrect) FontWeight.Bold else FontWeight.Normal
                                            )
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        IconButton(onClick = { editingQuestion = q }) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = IndigoPrimary)
                                        }
                                        IconButton(onClick = { onDeleteQuestion(q.id, selectedTest.id) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = RoseError)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddQuestionDialog && selectedTest != null) {
        QuestionDialog(
            question = null,
            onDismiss = { showAddQuestionDialog = false },
            onSave = { qText, options, correctIndex, marks ->
                onAddQuestion(selectedTest.id, qText, options, correctIndex, marks)
                showAddQuestionDialog = false
            }
        )
    }

    if (editingQuestion != null && selectedTest != null) {
        QuestionDialog(
            question = editingQuestion,
            onDismiss = { editingQuestion = null },
            onSave = { qText, options, correctIndex, marks ->
                onUpdateQuestion(editingQuestion!!.id, selectedTest.id, qText, options, correctIndex, marks)
                editingQuestion = null
            }
        )
    }
}

// TAB 4: DATABASE SETUP & DIAGNOSTICS
@Composable
fun AdminDatabaseSetupTab() {
    val clipboardManager = LocalClipboardManager.current
    val sqlScript = """
-- MOJILO MANISH SUPABASE SETUP SQL
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    mobile_number TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'student',
    is_active BOOLEAN NOT NULL DEFAULT true,
    active_device_id TEXT NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.tests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT true,
    reattempt_allowed BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.questions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    test_id UUID REFERENCES public.tests(id) ON DELETE CASCADE,
    question_text TEXT NOT NULL,
    options JSONB NOT NULL DEFAULT '[]'::jsonb,
    correct_option_index INT NOT NULL DEFAULT 0,
    marks INT NOT NULL DEFAULT 1
);

-- COMPLETED TESTS RECORD (ONLY student_id AND test_id)
CREATE TABLE IF NOT EXISTS public.completed_tests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    test_id UUID REFERENCES public.tests(id) ON DELETE CASCADE,
    completed_at TIMESTAMPTZ DEFAULT now()
);
    """.trimIndent()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = SlateSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Supabase SQL Schema",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    IconButton(onClick = { clipboardManager.setText(AnnotatedString(sqlScript)) }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy SQL", tint = IndigoPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                SelectionContainer {
                    Text(
                        text = sqlScript,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    )
                }
            }
        }
    }
}

// DIALOG HELPERS
@Composable
fun StudentDialog(
    student: UserProfile?,
    onDismiss: () -> Unit,
    onSave: (name: String, mobile: String, pass: String, isActive: Boolean) -> Unit
) {
    var name by remember { mutableStateOf(student?.name ?: "") }
    var mobile by remember { mutableStateOf(student?.mobileNumber ?: "") }
    var pass by remember { mutableStateOf(student?.password ?: "") }
    var isActive by remember { mutableStateOf(student?.isActive ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (student == null) "વિદ્યાર્થી ઉમેરો" else "વિદ્યાર્થી એડિટ કરો") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("નામ") }, singleLine = true)
                OutlinedTextField(value = mobile, onValueChange = { mobile = it }, label = { Text("મોબાઈલ નંબર") }, singleLine = true)
                OutlinedTextField(value = pass, onValueChange = { pass = it }, label = { Text("પાસવર્ડ") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isActive, onCheckedChange = { isActive = it })
                    Text("Active Student")
                }
            }
        },
        confirmButton = {
            Button(onClick = { if (name.isNotBlank() && mobile.isNotBlank()) onSave(name, mobile, pass, isActive) }) {
                Text("સેવ કરો")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("રદ કરો") } }
    )
}

@Composable
fun TestDialog(
    test: TestItem?,
    onDismiss: () -> Unit,
    onSave: (title: String, isActive: Boolean, reattemptAllowed: Boolean) -> Unit
) {
    var title by remember { mutableStateOf(test?.title ?: "") }
    var isActive by remember { mutableStateOf(test?.isActive ?: true) }
    var reattempt by remember { mutableStateOf(test?.reattemptAllowed ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (test == null) "નવી પરીક્ષા બનાવો" else "પરીક્ષા એડિટ કરો") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("પરીક્ષાનું નામ (Test Title)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = isActive, onCheckedChange = { isActive = it })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Active Test")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = reattempt, onCheckedChange = { reattempt = it })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Reattempt Allowed (ફરી પરીક્ષા આપી શકાય)")
                }
            }
        },
        confirmButton = {
            Button(onClick = { if (title.isNotBlank()) onSave(title, isActive, reattempt) }) {
                Text("સેવ કરો")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("રદ કરો") } }
    )
}

@Composable
fun QuestionDialog(
    question: QuestionItem?,
    onDismiss: () -> Unit,
    onSave: (qText: String, options: List<String>, correctIndex: Int, marks: Int) -> Unit
) {
    var qText by remember { mutableStateOf(question?.questionText ?: "") }
    var opt0 by remember { mutableStateOf(question?.options?.getOrNull(0) ?: "") }
    var opt1 by remember { mutableStateOf(question?.options?.getOrNull(1) ?: "") }
    var opt2 by remember { mutableStateOf(question?.options?.getOrNull(2) ?: "") }
    var opt3 by remember { mutableStateOf(question?.options?.getOrNull(3) ?: "") }
    var correctIndex by remember { mutableIntStateOf(question?.correctOptionIndex ?: 0) }
    var marks by remember { mutableStateOf((question?.marks ?: 1).toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (question == null) "નવો પ્રશ્ન ઉમેરો" else "પ્રશ્ન એડિટ કરો") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = qText,
                    onValueChange = { qText = it },
                    label = { Text("પ્રશ્નનું લખાણ (Question)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(value = opt0, onValueChange = { opt0 = it }, label = { Text("વિકલ્પ (A)") })
                OutlinedTextField(value = opt1, onValueChange = { opt1 = it }, label = { Text("વિકલ્પ (B)") })
                OutlinedTextField(value = opt2, onValueChange = { opt2 = it }, label = { Text("વિકલ્પ (C)") })
                OutlinedTextField(value = opt3, onValueChange = { opt3 = it }, label = { Text("વિકલ્પ (D)") })

                Text("સાચો વિકલ્પ પસંદ કરો:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("A", "B", "C", "D").forEachIndexed { idx, label ->
                        FilterChip(
                            selected = correctIndex == idx,
                            onClick = { correctIndex = idx },
                            label = { Text(label) }
                        )
                    }
                }

                OutlinedTextField(
                    value = marks,
                    onValueChange = { marks = it },
                    label = { Text("ગુણ (Marks)") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val opts = listOf(opt0, opt1, opt2, opt3)
                val m = marks.toIntOrNull() ?: 1
                if (qText.isNotBlank()) onSave(qText, opts, correctIndex, m)
            }) {
                Text("સેવ કરો")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("રદ કરો") } }
    )
}

private fun String?.isNull_or_empty(): Boolean = this == null || this.trim().isEmpty()
