package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remote.SupabaseConfig

@Composable
fun SupabaseConfigDialog(
    onDismiss: () -> Unit,
    onSave: (url: String, key: String) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var url by remember { mutableStateOf(SupabaseConfig.getSupabaseUrl(context)) }
    var key by remember { mutableStateOf(SupabaseConfig.getSupabaseAnonKey(context)) }
    var showSqlScript by remember { mutableStateOf(false) }

    val sqlScript = """
-- ==========================================
-- MOJILO MANISH - SUPABASE DATABASE SETUP SQL
-- ==========================================

-- 1. PROFILES TABLE
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    mobile_number TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'student',
    is_active BOOLEAN NOT NULL DEFAULT true,
    active_device_id TEXT NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 2. TESTS TABLE
CREATE TABLE IF NOT EXISTS public.tests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT true,
    reattempt_allowed BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 3. QUESTIONS TABLE
CREATE TABLE IF NOT EXISTS public.questions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    test_id UUID REFERENCES public.tests(id) ON DELETE CASCADE,
    question_text TEXT NOT NULL,
    options JSONB NOT NULL DEFAULT '[]'::jsonb,
    correct_option_index INT NOT NULL DEFAULT 0,
    marks INT NOT NULL DEFAULT 1
);

-- 4. COMPLETED TESTS TABLE (NO MARKS, NO SCORES, NO ANSWERS STORED)
CREATE TABLE IF NOT EXISTS public.completed_tests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    test_id UUID REFERENCES public.tests(id) ON DELETE CASCADE,
    completed_at TIMESTAMPTZ DEFAULT now()
);

-- DISABLE RLS FOR ANON ACCESS OR ENABLE PUBLIC POLICIES
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.tests DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.completed_tests DISABLE ROW LEVEL SECURITY;

-- SEED DEFAULT ADMIN AND DEMO STUDENT
INSERT INTO public.profiles (mobile_number, name, password, role)
VALUES ('7096684982', 'Mojilo Admin', 'Manish@2006', 'admin')
ON CONFLICT (mobile_number) DO NOTHING;

INSERT INTO public.profiles (mobile_number, name, password, role)
VALUES ('9876543210', 'Demo Student', '123456', 'student')
ON CONFLICT (mobile_number) DO NOTHING;
    """.trimIndent()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Supabase Backend Configuration",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "તમારું Supabase પ્રોજેક્ટ કનેક્ટ કરો:",
                    style = MaterialTheme.typography.bodyMedium
                )

                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("Supabase URL") },
                    leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    label = { Text("Supabase Anon Key") },
                    leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { showSqlScript = !showSqlScript }) {
                        Text(if (showSqlScript) "SQL સંતાડો" else "Supabase SQL Script જુઓ")
                    }

                    if (showSqlScript) {
                        IconButton(onClick = {
                            clipboardManager.setText(AnnotatedString(sqlScript))
                        }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy SQL")
                        }
                    }
                }

                if (showSqlScript) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        SelectionContainer {
                            Text(
                                text = sqlScript,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp
                                ),
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(url, key)
                onDismiss()
            }) {
                Text("સેવ કરો (Save)")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("રદ કરો (Cancel)")
            }
        }
    )
}
