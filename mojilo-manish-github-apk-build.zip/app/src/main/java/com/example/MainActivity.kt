package com.example

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.Screen
import com.example.ui.screens.*
import com.example.ui.theme.MojiloManishTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MojiloManishTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    InternetConnectionGate {
                        AppNavigation(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
private fun InternetConnectionGate(content: @Composable () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var isConnected by remember { mutableStateOf(isInternetAvailable(context)) }

    DisposableEffect(context) {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                isConnected = isInternetAvailable(context)
            }

            override fun onLost(network: Network) {
                isConnected = isInternetAvailable(context)
            }

            override fun onCapabilitiesChanged(
                network: Network,
                networkCapabilities: NetworkCapabilities
            ) {
                isConnected = networkCapabilities.hasCapability(
                    NetworkCapabilities.NET_CAPABILITY_VALIDATED
                )
            }
        }

        connectivityManager.registerDefaultNetworkCallback(callback)
        onDispose {
            runCatching { connectivityManager.unregisterNetworkCallback(callback) }
        }
    }

    if (isConnected) {
        content()
    } else {
        OfflineConnectionScreen(
            onRetry = { isConnected = isInternetAvailable(context) }
        )
    }
}

private fun isInternetAvailable(context: Context): Boolean {
    val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = connectivityManager.activeNetwork ?: return false
    val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false

    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}

@Composable
private fun OfflineConnectionScreen(onRetry: () -> Unit) {
    // Blocking full-screen connection screen: the app UI is not shown until
    // a validated internet connection is available.
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            androidx.compose.material3.Icon(
                imageVector = Icons.Filled.CloudOff,
                contentDescription = null,
                modifier = Modifier.size(120.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(28.dp))
            Text(
                text = "ઇન્ટરનેટ કનેક્શન જરૂરી છે",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                ),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "મોબાઈલ ડેટા અથવા Wi‑Fi ચાલુ કરો અને ઇન્ટરનેટ કનેક્શન ચકાસો.",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(28.dp))
            Button(
                onClick = onRetry,
                modifier = Modifier.fillMaxWidth(0.78f)
            ) {
                androidx.compose.material3.Icon(
                    imageVector = Icons.Filled.Refresh,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("ફરીથી ચકાસો")
            }
            Spacer(modifier = Modifier.height(48.dp))
            Text(
                text = "કનેક્શન ચાલુ કર્યા પછી 'ફરીથી ચકાસો' દબાવો.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Overlay Score Result Dialog when a test is submitted
    if (uiState.activeScoreResult != null) {
        ScoreResultDialog(
            scoreResult = uiState.activeScoreResult!!,
            onDismiss = { viewModel.dismissScoreResultDialog() }
        )
    }

    Crossfade(
        targetState = uiState.currentScreen,
        animationSpec = tween(durationMillis = 350),
        label = "screen_crossfade"
    ) { screen ->
        when (screen) {
            is Screen.Splash -> {
                SplashScreen(
                    onTimeout = { viewModel.onSplashFinished() }
                )
            }
            is Screen.Login -> {
                LoginScreen(
                    uiState = uiState,
                    onLoginClick = { mobile, pass -> viewModel.login(mobile, pass) },
                    onClearError = { viewModel.clearError() },
                    onSaveSupabaseConfig = { url, key -> viewModel.updateSupabaseConfig(url, key) }
                )
            }
            is Screen.StudentDashboard -> {
                StudentDashboardScreen(
                    user = uiState.currentUser,
                    tests = uiState.studentTests,
                    isLoading = uiState.isLoading,
                    onStartTest = { test -> viewModel.startTest(test) },
                    onRefresh = {
                        uiState.currentUser?.let { viewModel.loadStudentData(it.id) }
                    },
                    onLogout = { viewModel.logout() }
                )
            }
            is Screen.TakeTest -> {
                TakeTestScreen(
                    test = screen.test,
                    questions = uiState.testQuestions,
                    currentQuestionIndex = uiState.currentQuestionIndex,
                    selectedAnswers = uiState.selectedAnswers,
                    onSelectOption = { qId, optIdx -> viewModel.selectOption(qId, optIdx) },
                    onGoToQuestion = { idx -> viewModel.goToQuestion(idx) },
                    onSubmitTest = { viewModel.submitTest() },
                    onBack = { viewModel.dismissScoreResultDialog() }
                )
            }
            is Screen.AdminDashboard -> {
                AdminDashboardScreen(
                    user = uiState.currentUser,
                    students = uiState.adminStudents,
                    tests = uiState.adminTests,
                    selectedTestForQuestions = uiState.adminSelectedTestForQuestions,
                    questionsForTest = uiState.adminQuestionsForTest,
                    isLoading = uiState.isLoading,
                    onAddStudent = { name, mobile, pass -> viewModel.adminAddStudent(name, mobile, pass) },
                    onUpdateStudent = { id, name, mobile, pass, isActive ->
                        viewModel.adminUpdateStudent(id, name, mobile, pass, isActive)
                    },
                    onDeleteStudent = { id -> viewModel.adminDeleteStudent(id) },
                    onResetDeviceLock = { id -> viewModel.adminResetStudentDeviceLock(id) },
                    onCreateTest = { title, isActive, reattempt ->
                        viewModel.adminCreateTest(title, isActive, reattempt)
                    },
                    onUpdateTest = { id, title, isActive, reattempt ->
                        viewModel.adminUpdateTest(id, title, isActive, reattempt)
                    },
                    onDeleteTest = { id -> viewModel.adminDeleteTest(id) },
                    onSelectTestForQuestions = { test -> viewModel.adminSelectTestForQuestions(test) },
                    onAddQuestion = { testId, qText, options, correctIdx, marks ->
                        viewModel.adminAddQuestion(testId, qText, options, correctIdx, marks)
                    },
                    onUpdateQuestion = { id, testId, qText, options, correctIdx, marks ->
                        viewModel.adminUpdateQuestion(id, testId, qText, options, correctIdx, marks)
                    },
                    onDeleteQuestion = { id, testId -> viewModel.adminDeleteQuestion(id, testId) },
                    onLogout = { viewModel.logout() }
                )
            }
        }
    }
}
